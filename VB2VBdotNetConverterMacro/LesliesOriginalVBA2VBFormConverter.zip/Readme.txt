VBA�VB Form Converter
Ver 0.12 JAN-02-2003

Leslie Lowe
mookiha@hotmail.com



@----------------------------
@ VERSION HISTORY
@----------------------------

0.12 Several changes, see below
     NOTES:
      VFC now checks if it will be overwiting the output
      file form.

      The VFC form will now stay shown so you may easily
      convert more forms.

      After the form is converted VFC will show you the
      filename it has created, so it doesnt get lost.

      A report of unknown controls can be found in the
      immediate window.

      The main form name of frmVfcMain cannot be changed
      from this. VFC will now filter its own form for
      conversion.

      General code cleanup to evade trout slaps.

0.11 Not released

0.10 Public beta release
     NOTES:
      Supported controls:
        MSForms.Label
        MSForms.TextBox
        MSForms.CheckBox
        MSForms.OptionButton
        MSForms.CommandButton
        MSForms.ToggleButton
        MSForms.Image
        MSForms.ListBox
        MSForms.ComboBox
        MSForms.ScrollBar
        MSForms.Frame

      Unsupported Controls:
        MSForms.TabStrip
        MSForms.MultiPage
        MSForms.SpinButton
        All other external controls

      An option is available to create a placeholder
      for unsupported controls so you may easily place
      the control after the form is imported into VB.

      An option is available to copy the code within
      form being converted to the new VB form.

      Little error trapping exist in this version of
      VFC, one known issue is that all controls must
      have Height, Left, Top, and Width properties
      for VFC to complete properly. A work around to
      this is to uncheck the option 'Show Placeholders
      for Unknown Controls'.

      Most properties have been mapped to the VB
      counterparts. The properties that have not yet
      been mapped are Appearance and BorderStyle, and
      a select few others.

      Another issue is with the Frame container,
      controls should show properly when the font size
      is at or near 8pts. Other font sizes will cause
      an unpredictable offset.

      The converted form will be saved in the same
      directory as the DVB file. The name of the file
      will be the form name prefixed with "_VFC.frm".
      Currently VFC will not warn you of overwritting
      existing files.

      VFC does not makes use of the FRX file,
      properties such as Icons and Pictures will not
      be mapped and left blank.

      VFC does not support the use of the '&' as an
      accelerator, why youd want to in the first place
      is a mystery. All '&' within captions will show
      properly in VB as they will be converted to '&&'
      and the accelerator placed accordingly.

      VFC does not support the use of the carriage return
      or line feed in any string properties, ie Text,
      Caption, if used they will be replaced by the _
      underscore.

      Make a backup of your DVB file before using.

INSTALLATION:
      Create a new DVB project, import the 2 files
      frmVfcMain and modVfcMain. Add a reference to
      Microsoft Visual Basic for Applications Extensibility 5.3
      Save the DVB file.

USAGE:
      Load the DVB file with the form you want to convert.
      Run the macro "SelectFormToConvert", Select a Project
      and a Form. Makes changes to the options if needed.
      Select 'Convert'. A dialog will display when done.
      Import the newly created form into VB.

[END]
